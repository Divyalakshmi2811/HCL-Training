package org.hcl.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet1Sample")
public class Servlet1Sample extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Servlet1Sample() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<title>display</title>");
		pw.write("<h1 style=\"text-align:center; color:red;\">WELCOME TO PARADISE</h1>");
		pw.write("<div Styles=\"text-align:center);\">");
		pw.println("<p>The type of events</p>");
		pw.println("<ul>");
		
		
	
		pw.println("<li>Exhibition</li>");
		pw.println("<li>Stage Show</li>");
		pw.println("</ul>");
		pw.println("</body>");
		pw.println("</html>");
		pw.close();
		
		
	}

}
