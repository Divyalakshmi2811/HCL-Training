import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BankManager {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	public static bankNew getMappedAccount(List<bankNew> banklists,List<BankTransaction> banktransactions) throws IOException {
		System.out.println("Enter the user name to search");
		String name = br.readLine();
		
		bankNew newe = new bankNew();
	newe.setName(name);
	Stream<bankNew> str =banklists.stream();
	str.forEach((s)->System.out.println(s)};
	List<bankNew> banks = null;
	str.filter((s)->{return (((bankNew)str).getName()==name;}).forEach((ster) -> {System.out.println(ster);});	//S
	System.err.println(banks);
	
	
	return null;
	}	
}
