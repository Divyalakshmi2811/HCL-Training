import java.util.List;

public class Main1 {

	public static void main(String[] args) 
	{
	try {
		
			
			List<bankNew> callLogList = BankImpl.getDetails();
			System.out.println(callLogList);
			for(bankNew bank: callLogList) {
				System.err.println(bank.getName());
			}
			List<BankTransaction> b = BankTransactionImpl.getTransaction();
			for(BankTransaction bank : b) {
				System.err.println(bank.getCardNumber());
			}
			
			
			BankManager.getMappedAccount(callLogList, b);

	} catch (Exception e) {
		
		e.printStackTrace();
	}	
	
	
	

}
}
