import java.util.*;
import java.io.*;
import java.lang.*;
public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		TreeSet<Hall> t=new TreeSet<>();
		t.add(new Hall("SDH hall","12345",12000.0,"Jane"));
		t.add(new Hall("SRT hall","13579",20000.0,"John"));
		t.add(new Hall("XUV hal","24680",15000.0,"Jack"));
		System.out.println("Name     Contactnumber   Costperday  Ownername     ");
		System.out.println(t);
        }
        
	}


