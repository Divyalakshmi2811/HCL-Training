
public class Hall implements Comparable {
	String name;
	String contactNumber;
	Double costPerDay;
	String ownerName;
	public Hall()
	{
		
	}
	public Hall(String name, String contactNumber, Double costPerDay, String ownerName) {
		super();
		this.name = name;
		this.contactNumber = contactNumber;
		this.costPerDay = costPerDay;
		this.ownerName = ownerName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Double getCostPerDay() {
		return costPerDay;
	}
	public void setCostPerDay(Double costPerDay) {
		this.costPerDay = costPerDay;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
public int compareTo(Object obj)
{
	Hall h1=(Hall)obj;
	if(this.costPerDay<h1.getCostPerDay())
		return -1;
	else if(this.costPerDay>h1.getCostPerDay())
	    return 1;
	else
		return 0;
}
         
    

public String toString()
{
	
	return name+"\t"+contactNumber+"\t"+costPerDay+"\t"+"\t"+ownerName+"\n";
}

}
