import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.*;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		TreeSet<Address> list=new TreeSet<Address>();
		System.out.println("Enter the number of users:");
		int no=Integer.parseInt(br.readLine());
		System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
		for(int i=0;i<no;i++)
		{
			String str=br.readLine();
		    String arr[]=str.split(",");
		    Address a=new Address(arr[0],arr[1],arr[2],Integer.parseInt(arr[3]));
		    list.add(a);
		 }
		
		
		System.out.println("User Details");
		
		System.out.println(list);
		


		

	}

}
