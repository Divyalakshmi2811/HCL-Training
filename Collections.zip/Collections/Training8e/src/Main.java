
import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      Set<String> s=new HashSet<>();
      int x=1;
      String ch;
      while(true)
      {
    	  System.out.println("Enter username");
    	  String str=br.readLine();
    	  s.add(str);
    	  x++;
    	  System.out.println("Do you want to continue?(yes/no)");
    	  ch=br.readLine();
    	  if(ch.equals("yes"))
    		  continue;
    	  else if(ch.equals("no"))
    		  break;
      }
      
    	  System.out.println("Number of Users = "+s.size());
    	  
      }
      
            
}


