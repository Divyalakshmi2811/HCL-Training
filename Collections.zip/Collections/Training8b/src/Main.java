import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
		List<ItemType> list=new ArrayList<>();
		String name;
		double deposit,costPerDay;
		String str;
		int x=1;
		while(true)
		{
			System.out.println("Enter the details of Item Type 1");
			System.out.println("Name:");
			name=br.readLine();
			System.out.println("Deposit:");
			deposit=Double.parseDouble(br.readLine());
			System.out.println("Cost per Day:");
			costPerDay=Double.parseDouble(br.readLine());
			list.add(new ItemType(name,deposit,costPerDay));
			System.out.println("Do you want to continue?(y/n)");
			str=br.readLine();
			if(str.equals("y"))
			{
				x++;
				continue;
			}
			else
				break;
		}
		System.out.println("The names entered are:");
		System.out.printf("%-20s%-20s%-20s","Name","Deposit","costPerDay");
		System.out.println("\n");
		for(ItemType i:list)
		{
			System.out.println(i);
			
		}
	}

}
