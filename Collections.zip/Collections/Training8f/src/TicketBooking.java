import java.util.Collections;
import java.util.List;
import java.util.*;

public class TicketBooking {
	public TicketBooking()
	{
		
	}
	public TicketBooking(String customerName, int price) {
		super();
		this.customerName = customerName;
		this.price = price;
	}
	String customerName	;	
	int price;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String toString()
	{
		return String.format("%s spends minimum amount of Rs.%s\n",customerName,price,"%s spends maximum amount of Rs.%s",customerName,price);
		
		
    }
	
	
    void minPrice(List<TicketBooking>tb)
	{
		List<Integer> li=new ArrayList<Integer>();
		for(TicketBooking t:tb)
		{
			li.add(t.getPrice());
		}
		int x=li.indexOf(Collections.min(li));
		System.out.println(tb.get(x).toString());
		

		}
    void maxPrice(List<TicketBooking>tb)
    {
    	List<Integer> hi=new ArrayList<Integer>();
		for(TicketBooking t:tb)
		{
			hi.add(t.getPrice());
		}
		int x=hi.indexOf(Collections.max(hi));
		System.out.println(tb.get(x).toString());
		
    	
    }
	}
	



