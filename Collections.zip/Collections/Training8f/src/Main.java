import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args)throws IOException{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		List<TicketBooking> tb= new ArrayList<TicketBooking>();
		System.out.println("Enter the number of customers");
		int number=Integer.parseInt(br.readLine());
		System.out.println("Enter the booking price accordingly with customer name in CSV");
		for(int i=0;i<number;i++)
		{
			
		    String str=br.readLine();
		    String arr[]=str.split(",");
		    tb.add(new TicketBooking(arr[0],Integer.parseInt(arr[1])));
		}
		TicketBooking t=new TicketBooking();
		t.minPrice(tb);
		t.maxPrice(tb);
		

	}

}
