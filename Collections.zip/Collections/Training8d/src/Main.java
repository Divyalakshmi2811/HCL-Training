import java.util.*;
import java.io.*;
public class Main {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      Set<String> s=new HashSet<>();
      int x=1;
      String ch;
      while(true)
      {
    	  System.out.println("Enter the username"+x);
    	  String str=br.readLine();
    	  s.add(str);
    	  x++;
    	  System.out.println("Do you want to continue?(Y/N)");
    	  ch=br.readLine();
    	  if(ch.equals("y"))
    		  continue;
    	  else if(ch.equals("n"))
    		  break;
      }
      
    	  System.out.println("The unique number of usernames is "+s.size());
    	  
      }
      
            
	}


