import java.util.Iterator;
import java.io.*;
import java.lang.*;
import java.util.*;

public class Stall {
	public Stall()
	{
		
	}
		public Stall(String name, String detail, String type, String ownerName) {
		super();
		this.name = name;
		this.detail = detail;
		this.type = type;
		this.ownerName = ownerName;
	}
		String name;
		String detail;
		String type;
		String ownerName;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDetail() {
			return detail;
		}
		public void setDetail(String detail) {
			this.detail = detail;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getOwnerName() {
			return ownerName;
		}
		public void setOwnerName(String ownerName) {
			this.ownerName = ownerName;
		}
		public String toString()
		{
			return String.format("%-15s%-15s%-15s%-15s","Name","Detail","Type","OwnerName");
		}
		void removeTest(List<Stall> lt)
		{
			Iterator<Stall> itr=lt.iterator();
			while(itr.hasNext()) {
				if(itr.next().getName().startsWith("test"))
					itr.remove();
			}
				
		}
		
			public void display(List<Stall> lt)
			{
				System.out.printf("%-15s%-15s%-15s%-15s\n","Name","Detail","Type","OwnerName");
				for(Stall ele:lt)
				{   
					System.out.printf("%-15s%-15s%-15s%-15s\n",ele.name,ele.detail,ele.type,ele.ownerName);
				}
			}
		}



