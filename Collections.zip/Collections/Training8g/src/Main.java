import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.util.*;
import java.lang.*;

public class Main {

	public static void main(String[] args)throws IOException,ClassCastException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<Stall> list= new ArrayList<Stall>();
		System.out.println("Enter the number of stall details");
		int number=Integer.parseInt(br.readLine());
		int x=1;
		
		for(int i=0;i<number;i++)
		{   System.out.println("Enter the detail of stall "+x);
			String str=br.readLine();
		    String arr[]=str.split(",");
		    Stall s=new Stall(arr[0],arr[1],arr[2],arr[3]);
		    list.add(s);
		    x++;
		}
       
	Stall s1=new Stall();
	s1.removeTest(list);
	s1.display(list);
      
    	   
      
       }
}
       
       
       
	
	

