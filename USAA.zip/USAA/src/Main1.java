import java.util.List;
import java.util.Set;

public class Main1 {

	public static void main(String[] args) {
		try {

			List<BankAccount> banklist = BankImpl.getDetails();
			System.out.println(banklist);
			for (BankAccount bank : banklist) {
				System.err.println(bank.getName());
			}
			List<BankTransaction> bank1 = BankTransactionImpl.getTransaction();
			System.out.println(bank1);
			for (BankTransaction bank : bank1) {
				System.err.println(bank.getCardNumber());
			}

			List<BankAccount> lists = BankManager.getMappedAccount(banklist, bank1);
			System.out.println(lists);
			System.out.format("\n%-5s %-20s %-20s %-20s %-20s %-20s %-20s", "S.No", "Name", "Bank", "Age", "Gender",
					"TranscationDate", "TransactionAmount");

			for (BankAccount bank : lists) {

				Set<String> keysets = bank.getMapped().keySet();
				int serialnumber = 1;
				int number = 0;
				for (String key : keysets) {
					// System.out.println(key + "============>");
					List<BankTransaction> list = bank.getMapped().get(key);
					for (BankTransaction bnk : list) {
						if (number == 0)
							System.out.format("\n%-5s %-20s %-20s %-20s %-20s %-20s %-20s", serialnumber, bank.getName(),
									bank.getBank(), bank.getAge(), bank.getGender(), bnk.getTransactionDate(),
									bnk.getAmount());
						else
							System.out.format("\n%-5s %-20s %-20s %-20s %-20s %-20s %-20s", "", bank.getName(),
									bank.getBank(), bank.getAge(), bank.getGender(), bnk.getTransactionDate(),
									bnk.getAmount());
						number++;
						serialnumber++;
					}

				}

			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}
}
